package com.xs.mybatisplusgenerator.util;

public class PageBean<T> {

    public static final long DEFAULT_PAGE_NUM = 1L;
    public static final long DEFAULT_PAGE_SIZE = 10L;
    public static final String ORDER_TYPE_ASC = "ASC";
    public static final String ORDER_TYPE_DESC = "DESC";
    private Integer pageNum;
    private Integer pageSize;
    private String orderField;
    private String orderType;
    private T queryTerms;

    public PageBean() {
    }

    public Integer getPageNum() {
        return pageNum;
    }

    public void setPageNum(Integer pageNum) {
        this.pageNum = pageNum;
    }

    public Integer getPageSize() {
        return pageSize;
    }

    public void setPageSize(Integer pageSize) {
        this.pageSize = pageSize;
    }

    public String getOrderField() {
        return orderField;
    }

    public void setOrderField(String orderField) {
        this.orderField = orderField;
    }

    public String getOrderType() {
        return orderType;
    }

    public void setOrderType(String orderType) {
        this.orderType = orderType;
    }

    public T getQueryTerms() {
        return queryTerms;
    }

    public void setQueryTerms(T queryTerms) {
        this.queryTerms = queryTerms;
    }
}
