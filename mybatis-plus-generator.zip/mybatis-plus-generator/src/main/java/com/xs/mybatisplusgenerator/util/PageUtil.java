package com.xs.mybatisplusgenerator.util;

import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.core.metadata.OrderItem;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import org.springframework.util.StringUtils;

public class PageUtil {
    public PageUtil() {
    }

    public static IPage getPage(PageBean params) {
        return getPage(params, (String)null, false);
    }

    public static IPage getPage(PageBean params, String defaultOrderField, boolean isAsc) {
        long current = 1L;
        long size = 10L;
        if (params.getPageNum() != null) {
            try {
                current = Long.parseLong(String.valueOf(params.getPageNum()));
            } catch (Exception var9) {
                current = 1L;
            }
        }

        if (params.getPageSize() != null) {
            try {
                size = Long.parseLong(String.valueOf(params.getPageSize()));
            } catch (Exception var8) {
                size = 10L;
            }
        }

        Page<?> page = new Page(current, size);
        if (StringUtils.hasText(params.getOrderField())) {
            return "ASC".equalsIgnoreCase(params.getOrderType()) ? page.addOrder(new OrderItem[]{OrderItem.asc(params.getOrderField())}) : page.addOrder(new OrderItem[]{OrderItem.desc(params.getOrderField())});
        } else if (!StringUtils.hasText(defaultOrderField)) {
            return page;
        } else {
            return isAsc ? page.addOrder(new OrderItem[]{OrderItem.asc(defaultOrderField)}) : page.addOrder(new OrderItem[]{OrderItem.desc(defaultOrderField)});
        }
    }
}
