package com.xs.mybatisplusgenerator.service.impl;

import com.xs.mybatisplusgenerator.entity.EffortsStatusMessage;
import com.xs.mybatisplusgenerator.mapper.EffortsStatusMessageMapper;
import com.xs.mybatisplusgenerator.service.EffortsStatusMessageService;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import org.springframework.stereotype.Service;

/**
 * <p>
 *  服务实现类
 * </p>
 *
 * @author xs
 * @since 2023-03-16
 */
@Service
public class EffortsStatusMessageServiceImp extends ServiceImpl<EffortsStatusMessageMapper, EffortsStatusMessage> implements EffortsStatusMessageService {

}
