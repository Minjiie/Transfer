package com.xs.mybatisplusgenerator.service;

import com.xs.mybatisplusgenerator.entity.EffortsStatusMessage;
import com.baomidou.mybatisplus.extension.service.IService;

/**
 * <p>
 *  服务类
 * </p>
 *
 * @author xs
 * @since 2023-03-16
 */
public interface EffortsStatusMessageService extends IService<EffortsStatusMessage> {

}
