package com.xs.mybatisplusgenerator.entity;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import java.io.Serializable;
import java.time.LocalDateTime;
import io.swagger.annotations.ApiModel;
import lombok.Getter;
import lombok.Setter;

/**
 * <p>
 * 
 * </p>
 *
 * @author xs
 * @since 2023-03-16
 */
@Getter
@Setter
@TableName("efforts_status_message")
@ApiModel(value = "EffortsStatusMessage对象")
public class EffortsStatusMessage implements Serializable {

    private static final long serialVersionUID = 1L;

    @TableId(value = "ID", type = IdType.AUTO)
    private Long id;

    @TableField("message_content")
    private String messageContent;

    @TableField("send_status")
    private String sendStatus;

    @TableField("module_name")
    private String moduleName;

    @TableField("create_by")
    private String createBy;

    @TableField("create_date")
    private LocalDateTime createDate;

    @TableField("last_modify_by")
    private String lastModifyBy;

    @TableField("last_modify_date")
    private LocalDateTime lastModifyDate;


}
