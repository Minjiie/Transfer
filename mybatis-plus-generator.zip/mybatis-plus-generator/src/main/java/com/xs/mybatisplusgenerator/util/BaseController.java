package com.xs.mybatisplusgenerator.util;

import com.alibaba.fastjson.JSON;
import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.extension.service.IService;
import io.swagger.annotations.ApiOperation;
import lombok.extern.log4j.Log4j2;
import org.apache.poi.ss.usermodel.*;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.io.*;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.util.*;
import java.util.stream.Collectors;

@Log4j2
public abstract class BaseController<S extends IService<T>,T,PK> {

    @Autowired
    protected S service;

    @PostMapping("/findPage")
    @ApiOperation(value = "获取 对象 分页信息", notes = "获取 对象 分页信息 对象条件查询")
    public ResponseEntity<IPage<T>> findPageV1(@RequestBody PageBean<T> pageVo) {
		log.info("findPage pageVo:{}", JSON.toJSON(pageVo));
		try {
			return ResponseEntity.data(service.page(PageUtil.getPage(pageVo),WrapperUtil.entity2Wrapper(pageVo.getQueryTerms())));
		}catch (Exception e){
			log.warn(e.getMessage(),e);
			return null;
		}
    }

    @PostMapping("/find")
    @ApiOperation(value = "获取集合信息", notes = "获取集合信息，对象条件查询")
    public ResponseEntity<List<T>> find(@RequestBody T t){
		log.info("find model:{}",t);
		try {
			return ResponseEntity.data(service.list(WrapperUtil.entity2Wrapper(t)));
		}catch (Exception e){
			log.warn(e.getMessage(),e);
			return null;
		}
    }

    @GetMapping("/getAll")
    public ResponseEntity<List<T>> getAll(){
        return ResponseEntity.data(service.list());
    }

    /** 根据ID获取对象信息接口
	 *
	 * @param id 主键
	 * @return 对象信息JSON
     * */
	@GetMapping(value = "/{id}")
	@ApiOperation(value = "根据ID查询记录", notes = "根据ID查询记录")
	public ResponseEntity<T> getModel(@PathVariable("id") PK id) {
		return ResponseEntity.data(service.getById((Serializable) id));
	}


    	/** 创建对象
	 *
	 * @param t 待创建的对象
	 * @return 执行状态 */
	@PostMapping("/create")
	@ApiOperation(value = "保存记录", notes = "保存记录")
	public ResponseEntity<Boolean> createModel(@RequestBody T t) {
		log.info("create model:{}",t);
		return ResponseEntity.data(service.save(t));
	}

	/** 根据 主键 更新对象数据
	 *
	 * @param t 待更新的对象数据
	 * @return */
	@PostMapping("/updateById")
	@ApiOperation(value = "更新记录", notes = "更新记录")
	public ResponseEntity<Boolean> updateModel(@RequestBody T t) {
		log.info("updateById model:{}",t);
		return ResponseEntity.data(service.updateById(t));
	}


	/** 根据 主键 删除对象信息
	 *
	 * @param id 主键
	 * @return */
	@DeleteMapping(value = "/{id}")
	@ApiOperation(value = "根据ID删除记录", notes = "根据ID删除记录")
	public ResponseEntity<Boolean> deleteModel(@PathVariable("id") PK id) {
		log.info("delete id:{}",id);
		return ResponseEntity.data(service.removeById((Serializable) id));
	}

	@PostMapping("/exportExcel")
	@ApiOperation(value = "导出该对象数据库所有纪录")
	public <T> void exportExcel(T t){
		Class<?> aClass = t.getClass();
		List<Field> fields = Arrays.stream(aClass.getDeclaredFields()).filter(item -> !item.getName().equals("serialVersionUID")).collect(Collectors.toList());
		XSSFWorkbook book=new XSSFWorkbook();
		XSSFSheet sheet= book.createSheet(t.getClass().getName());
		Row row=sheet.createRow(0);
		for (int i = 0; i < fields.size(); i++) {
			row.createCell(i).setCellValue(fields.get(i).getName());
		}
		try {
			List<T> list = (List<T>) service.list();
			for (int i = 0; i < list.size(); i++) {
				row = sheet.createRow(i + 1);
				for (int j = 0; j < fields.size(); j++) {
					Class<?> bClass = list.get(i).getClass();
					List<Field> bFields = Arrays.stream(bClass.getDeclaredFields()).filter(item -> !item.getName().equals("serialVersionUID")).collect(Collectors.toList());
					Method method = bClass.getDeclaredMethod("get" + captureName(bFields.get(j).getName()), null);
					Object returnValue = method.invoke(list.get(i));
					row.createCell(j).setCellValue(returnValue==null?"":returnValue.toString());
				}
			}
			book.write(new FileOutputStream(new File("/Users/xuanzhang/Documents/dbName.xls")));
		}catch (Exception e){
			e.printStackTrace();
			System.out.println(e.getMessage());
		}
	}
	private static String captureName(String str) {
		// 进行字母的ascii编码前移，效率要高于截取字符串进行转换的操作
		char[] cs = str.toCharArray();
		cs[0] -= 32;
		return String.valueOf(cs);
	}
}
