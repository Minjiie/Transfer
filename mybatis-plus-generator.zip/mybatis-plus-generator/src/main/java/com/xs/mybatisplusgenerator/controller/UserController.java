package com.xs.mybatisplusgenerator.controller;

import com.xs.mybatisplusgenerator.UserDTO;
import com.xs.mybatisplusgenerator.entity.User;
import com.xs.mybatisplusgenerator.service.UserService;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import com.xs.mybatisplusgenerator.util.BaseController;

import java.util.List;

/**
 * <p>
 * 用户表 前端控制器
 * </p>
 *
 * @author xs
 * @since 2023-03-16
 */
@RestController
@RequestMapping("/mybatisplusgenerator/user")
public class UserController extends BaseController<UserService, User,Integer> {

    @PostMapping("/chaxun")
    public List<User> chaxun(@RequestBody UserDTO user){
        return service.list(user.toWrapper(user));
    }
}
