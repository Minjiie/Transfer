package com.xs.mybatisplusgenerator;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.generator.FastAutoGenerator;
import com.baomidou.mybatisplus.generator.config.DataSourceConfig;
import com.baomidou.mybatisplus.generator.config.OutputFile;
import com.baomidou.mybatisplus.generator.config.converts.MySqlTypeConvert;
import com.baomidou.mybatisplus.generator.config.querys.MySqlQuery;
import com.baomidou.mybatisplus.generator.engine.FreemarkerTemplateEngine;
import com.baomidou.mybatisplus.generator.keywords.MySqlKeyWordsHandler;
import com.xs.mybatisplusgenerator.util.BaseController;

import java.util.Collections;

public class AutoGenerator {

    public static void main(String[] args) {
        String projectPath = System.getProperty("user.dir"); //当前路径
        FastAutoGenerator.create("jdbc:mysql://localhost:3306/xs?useSSL=true&useUnicode=true&characterEncoding=utf-8&serverTimezone=GMT%2B8", "root", "sasa")
                //1、全局配置
                .globalConfig(builder -> {
                    builder.author("xs")//作者
                            .enableSwagger()//开启swagger
                            .disableOpenDir()
                            .outputDir(projectPath+"/src/main/java");//输出目录
                })
                //2、包配置
                .packageConfig(builder -> {
                    builder.parent("com.xs")//父包名
                            .moduleName("mybatisplusgenerator")//模块名
                            .pathInfo(Collections.singletonMap(OutputFile.xml,projectPath+"/src/main/resources/mapper")); //设置mapper xml生成路径
                })
                //3、策略配置
                .strategyConfig(builder -> {
                    builder.addInclude("TM_NEIT_PWO_HISTORY")//生成的表名
                            .addTablePrefix("t_","c_")//过滤表前缀
                            .entityBuilder()
                            .enableLombok()
                            .enableTableFieldAnnotation()
                            .idType(IdType.ASSIGN_UUID)
//                            .superClass("com.xs.mybatisplusgenerator.BaseEntity")
//                            .addSuperEntityColumns("id", "created_by", "created_time", "updated_by", "updated_time")
                            .controllerBuilder()
                            .enableRestStyle()
                            .superClass(BaseController.class)
                            .serviceBuilder()
                            .formatServiceFileName("%sService")
                            .formatServiceImplFileName("%sServiceImp");

                })
                .templateEngine(new FreemarkerTemplateEngine())//使用freemarker引擎模版
                .execute();
        //4、数据库配置
        new DataSourceConfig.Builder("jdbc:mysql://localhost:3306/xs?useSSL=true&useUnicode=true&characterEncoding=utf-8&serverTimezone=GMT%2B8", "root", "sasa")
                .dbQuery(new MySqlQuery())
                .schema("mybatis_plus")
                .typeConvert(new MySqlTypeConvert())
                .keyWordsHandler(new MySqlKeyWordsHandler())
                .build();
    }
}
