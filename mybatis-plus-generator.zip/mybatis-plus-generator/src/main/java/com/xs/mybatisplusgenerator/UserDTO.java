package com.xs.mybatisplusgenerator;

import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.xs.mybatisplusgenerator.entity.User;
import lombok.Data;

@Data
public class UserDTO {
    private Integer userId;

    private String userName;

    private Integer userSex;

    private Integer userAge;

    public LambdaQueryWrapper<User> toWrapper(UserDTO dto) {
        LambdaQueryWrapper<User> lambdaQueryWrapper =new LambdaQueryWrapper<>();
        lambdaQueryWrapper.eq(dto.getUserId()!=null,User::getUserId,dto.getUserId());
        lambdaQueryWrapper.like(dto.getUserName()!=null,User::getUserName,dto.getUserName());
        lambdaQueryWrapper.eq(dto.getUserSex()!=null,User::getUserSex,dto.getUserSex());
        lambdaQueryWrapper.eq(dto.getUserAge()!=null,User::getUserAge,dto.getUserAge());
        return lambdaQueryWrapper;
    }
}
