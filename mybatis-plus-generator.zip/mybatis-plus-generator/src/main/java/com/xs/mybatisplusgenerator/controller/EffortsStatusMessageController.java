package com.xs.mybatisplusgenerator.controller;

import com.xs.mybatisplusgenerator.entity.EffortsStatusMessage;
import com.xs.mybatisplusgenerator.service.EffortsStatusMessageService;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import com.xs.mybatisplusgenerator.util.BaseController;

/**
 * <p>
 *  前端控制器
 * </p>
 *
 * @author xs
 * @since 2023-03-16
 */
@RestController
@RequestMapping("/mybatisplusgenerator/effortsStatusMessage")
public class EffortsStatusMessageController extends BaseController<EffortsStatusMessageService, EffortsStatusMessage,Long> {

}
