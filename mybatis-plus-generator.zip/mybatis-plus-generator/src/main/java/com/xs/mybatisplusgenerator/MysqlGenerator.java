package com.xs.mybatisplusgenerator;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.baomidou.mybatisplus.extension.service.IService;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.baomidou.mybatisplus.generator.AutoGenerator;
import com.baomidou.mybatisplus.generator.config.*;
import com.baomidou.mybatisplus.generator.config.converts.MySqlTypeConvert;
import com.baomidou.mybatisplus.generator.config.po.LikeTable;
import com.baomidou.mybatisplus.generator.config.querys.MySqlQuery;
import com.baomidou.mybatisplus.generator.config.rules.DateType;
import com.baomidou.mybatisplus.generator.config.rules.NamingStrategy;
import com.baomidou.mybatisplus.generator.keywords.MySqlKeyWordsHandler;

import java.util.Collections;


public class MysqlGenerator {
    private static final DataSourceConfig DATA_SOURCE_CONFIG = new DataSourceConfig
            .Builder("jdbc:oracle:thin:@xxxx:1521:helowin", "system", "system")
            .schema("ANONYMOUS")
            .build();

    public static void main(String[] args) {

        String projectPath = System.getProperty("user.dir"); //当前路径
        System.out.println("1");
        DataSourceConfig build = new DataSourceConfig.Builder("jdbc:mysql://localhost:3306/xs?useSSL=true&useUnicode=true&characterEncoding=utf-8&serverTimezone=GMT%2B8", "root", "sasa")
                .build();
        System.out.println("2");

        GlobalConfig globalConfig = new GlobalConfig.Builder()
                .outputDir(projectPath + "/src/main/java")
                .author("xs")
                .enableSwagger()
                .dateType(DateType.TIME_PACK)
                .commentDate("yyyy-MM-dd")
                .build();
        System.out.println("3");

        PackageConfig packageConfig = new PackageConfig.Builder()
                .parent("com.xs")
                .moduleName("mybatisplusgenerator")
                .entity("entity")
                .service("service")
                .serviceImpl("service.impl")
                .mapper("mapper")
                .xml("mapper.xml")
                .controller("controller")
                .pathInfo(Collections.singletonMap(OutputFile.xml, projectPath + "/src/main/resources/mapper"))
                .build();
        System.out.println("4");
        TemplateConfig templateConfig = new TemplateConfig.Builder()
                .disable(TemplateType.ENTITY)
                .entity("/templates/entity.java")
                .service("/templates/service.java")
                .serviceImpl("/templates/serviceImpl.java")
                .mapper("/templates/mapper.java")
                .xml("/templates/mapper.xml")
                .controller("/templates/controller.java")
                .build();
        System.out.println("5");
        StrategyConfig strategyConfig = new StrategyConfig.Builder()
                .enableCapitalMode()
                .enableSkipView()
                .disableSqlFilter()
                .likeTable(new LikeTable("USER"))
                .addInclude("t_user")
                .addTablePrefix("t_", "c_")
                .addFieldSuffix("_flag")
                .build();
        System.out.println("6");
        StrategyConfig entity = new StrategyConfig.Builder()
                .entityBuilder()
                .superClass("com.xs.mybatisplusgenerator.BaseEntity")
                .disableSerialVersionUID()
                .enableChainModel()
                .enableLombok()
                .enableTableFieldAnnotation()
                .naming(NamingStrategy.no_change)
                .columnNaming(NamingStrategy.underline_to_camel)
                .addSuperEntityColumns("id", "created_by", "created_time", "updated_by", "updated_time")
                .idType(IdType.AUTO)
                .build();
        System.out.println("7");
        StrategyConfig controller = new StrategyConfig.Builder()
                .controllerBuilder()
                .superClass("com.xs.mybatisplusgenerator.BaseController")
                .enableHyphenStyle()
                .enableRestStyle()
                .build();
        System.out.println("8");
        StrategyConfig service = new StrategyConfig.Builder()
                .serviceBuilder()
                .superServiceClass(IService.class)
                .superServiceImplClass(ServiceImpl.class)
                .formatServiceFileName("%sService")
                .formatServiceImplFileName("%sServiceImp")
                .build();
        System.out.println("9");
        StrategyConfig mapper = new StrategyConfig.Builder()
                .mapperBuilder()
                .superClass(BaseMapper.class)
                .enableMapperAnnotation()
                .enableBaseResultMap()
                .enableBaseColumnList()
                .formatMapperFileName("%sMapper")
                .formatXmlFileName("%sXml")
                .build();
        System.out.println("10");
        new DataSourceConfig.Builder("jdbc:mysql://localhost:3306/xs?useSSL=true&useUnicode=true&characterEncoding=utf-8&serverTimezone=GMT%2B8", "root", "sasa")
                .dbQuery(new MySqlQuery())
                .schema("mybatis_plus")
                .typeConvert(new MySqlTypeConvert())
                .keyWordsHandler(new MySqlKeyWordsHandler())
                .build();

        AutoGenerator generator = new AutoGenerator(build);
        generator.strategy(mapper);
        generator.global(globalConfig);
        generator.execute();
    }
}
