package com.xs.mybatisplusgenerator.service.impl;

import com.xs.mybatisplusgenerator.entity.User;
import com.xs.mybatisplusgenerator.mapper.UserMapper;
import com.xs.mybatisplusgenerator.service.UserService;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import org.springframework.stereotype.Service;

/**
 * <p>
 * 用户表 服务实现类
 * </p>
 *
 * @author xs
 * @since 2023-03-16
 */
@Service
public class UserServiceImp extends ServiceImpl<UserMapper, User> implements UserService {

}
