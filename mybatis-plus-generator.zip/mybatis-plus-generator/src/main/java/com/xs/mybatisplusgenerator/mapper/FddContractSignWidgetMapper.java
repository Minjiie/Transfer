package com.xs.mybatisplusgenerator.mapper;

import com.xs.mybatisplusgenerator.entity.FddContractSignWidget;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;

/**
 * <p>
 * 合同签署控件表，保存签署方需要填写的控件信息 Mapper 接口
 * </p>
 *
 * @author xs
 * @since 2023-03-16
 */
public interface FddContractSignWidgetMapper extends BaseMapper<FddContractSignWidget> {

}
