package com.xs.mybatisplusgenerator.mapper;

import com.xs.mybatisplusgenerator.entity.User;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;

/**
 * <p>
 * 用户表 Mapper 接口
 * </p>
 *
 * @author xs
 * @since 2023-03-16
 */
public interface UserMapper extends BaseMapper<User> {

}
