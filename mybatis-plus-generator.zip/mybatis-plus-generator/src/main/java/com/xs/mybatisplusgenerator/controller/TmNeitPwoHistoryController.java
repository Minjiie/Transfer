package com.xs.mybatisplusgenerator.controller;

import com.xs.mybatisplusgenerator.entity.TmNeitPwoHistory;
import com.xs.mybatisplusgenerator.entity.User;
import com.xs.mybatisplusgenerator.service.TmNeitPwoHistoryService;
import com.xs.mybatisplusgenerator.service.UserService;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import com.xs.mybatisplusgenerator.util.BaseController;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * <p>
 *  前端控制器
 * </p>
 *
 * @author xs
 * @since 2023-03-27
 */
@RestController
@RequestMapping("/mybatisplusgenerator/tmNeitPwoHistory")
public class TmNeitPwoHistoryController extends BaseController<TmNeitPwoHistoryService, TmNeitPwoHistory,String> {

    @PostMapping("/chax")
    public void find(){
        List<TmNeitPwoHistory> list = service.list();
        Map<String,Integer> map = new HashMap<>();
        for (TmNeitPwoHistory tmNeitPwoHistory : list) {
//            System.out.println(tmNeitPwoHistory.getModeloption());
            String[] split = tmNeitPwoHistory.getModeloption().split(",");
            for (String splitStr : split) {
                String[] s = splitStr.split(" ");
                if (s.length>2&&s[2].length()>4){
                    System.out.println(s[2].substring(0,5));
                    if (map.containsKey(s[2].substring(0,5))) {
                        map.put(s[2].substring(0,5),map.get(s[2].substring(0,5))+1);
                    }else{
                        map.put(s[2].substring(0,5),1);
                    }
                }
            }
        }
        System.out.println(map);
    }
}
