package com.xs.mybatisplusgenerator.entity;

import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableName;
import java.io.Serializable;
import java.time.LocalDateTime;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Getter;
import lombok.Setter;

/**
 * <p>
 * 
 * </p>
 *
 * @author xs
 * @since 2023-03-27
 */
@Getter
@Setter
@TableName("TM_NEIT_PWO_HISTORY")
@ApiModel(value = "TmNeitPwoHistory对象", description = "")
public class TmNeitPwoHistory implements Serializable {

    private static final long serialVersionUID = 1L;

    @TableField("id")
    private String id;

    @TableField("pwonumber")
    private String pwonumber;

    @TableField("releasedate")
    private LocalDateTime releasedate;

    @TableField("book")
    private String book;

    @TableField("program")
    private String program;

    @TableField("modelyear")
    private String modelyear;

    @TableField("upc")
    private String upc;

    @TableField("fna")
    private String fna;

    @TableField("partnumber")
    private String partnumber;

    @TableField("action")
    private String action;

    @TableField("quantity")
    private String quantity;

    @TableField("modeloption")
    private String modeloption;

    @TableField("modelcode")
    private String modelcode;


}
