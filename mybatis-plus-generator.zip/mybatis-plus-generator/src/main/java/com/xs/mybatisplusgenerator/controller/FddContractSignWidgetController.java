package com.xs.mybatisplusgenerator.controller;

import com.xs.mybatisplusgenerator.entity.FddContractSignWidget;
import com.xs.mybatisplusgenerator.service.FddContractSignWidgetService;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import com.xs.mybatisplusgenerator.util.BaseController;

/**
 * <p>
 * 合同签署控件表，保存签署方需要填写的控件信息 前端控制器
 * </p>
 *
 * @author xs
 * @since 2023-03-16
 */
@RestController
@RequestMapping("/mybatisplusgenerator/fddContractSignWidget")
public class FddContractSignWidgetController extends BaseController<FddContractSignWidgetService, FddContractSignWidget,String> {

}
