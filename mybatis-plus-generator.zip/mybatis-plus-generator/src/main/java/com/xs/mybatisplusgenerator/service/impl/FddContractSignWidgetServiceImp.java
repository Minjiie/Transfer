package com.xs.mybatisplusgenerator.service.impl;

import com.xs.mybatisplusgenerator.entity.FddContractSignWidget;
import com.xs.mybatisplusgenerator.mapper.FddContractSignWidgetMapper;
import com.xs.mybatisplusgenerator.service.FddContractSignWidgetService;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import org.springframework.stereotype.Service;

/**
 * <p>
 * 合同签署控件表，保存签署方需要填写的控件信息 服务实现类
 * </p>
 *
 * @author xs
 * @since 2023-03-16
 */
@Service
public class FddContractSignWidgetServiceImp extends ServiceImpl<FddContractSignWidgetMapper, FddContractSignWidget> implements FddContractSignWidgetService {

}
