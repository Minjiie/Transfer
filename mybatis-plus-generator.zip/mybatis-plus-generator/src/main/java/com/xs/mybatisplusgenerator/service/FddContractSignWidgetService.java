package com.xs.mybatisplusgenerator.service;

import com.xs.mybatisplusgenerator.entity.FddContractSignWidget;
import com.baomidou.mybatisplus.extension.service.IService;

/**
 * <p>
 * 合同签署控件表，保存签署方需要填写的控件信息 服务类
 * </p>
 *
 * @author xs
 * @since 2023-03-16
 */
public interface FddContractSignWidgetService extends IService<FddContractSignWidget> {

}
