package com.xs.mybatisplusgenerator.service;

import com.xs.mybatisplusgenerator.entity.TmNeitPwoHistory;
import com.baomidou.mybatisplus.extension.service.IService;

/**
 * <p>
 *  服务类
 * </p>
 *
 * @author xs
 * @since 2023-03-27
 */
public interface TmNeitPwoHistoryService extends IService<TmNeitPwoHistory> {

}
