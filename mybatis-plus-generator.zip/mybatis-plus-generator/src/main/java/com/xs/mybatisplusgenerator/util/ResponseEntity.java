package com.xs.mybatisplusgenerator.util;


import lombok.Data;

@Data
public class ResponseEntity<T> {
    private Integer state;
    private String message;
    private T data;

    public static <T> ResponseEntity<T> data(final T data){
        ResponseEntity<T> response = new ResponseEntity<>();
        response.setData(data);
        response.setState(1);
        response.setMessage("");
        return response;
    }
    public static <T> ResponseEntity<T> ok(){
        ResponseEntity<T> response = new ResponseEntity<>();
        response.setState(1);
        response.setMessage("");
        return response;
    }
    public static ResponseEntity<String> error(String errorMsg){
        ResponseEntity<String> response = new ResponseEntity<>();
        response.setState(0);
        response.setData(errorMsg);
        response.setMessage(errorMsg);
        return response;
    }
    public static <T> ResponseEntity<T> errorWithData(String errorMsg,final T data){
        ResponseEntity<T> response= new ResponseEntity<>();
        response.setMessage(errorMsg);
        response.setState(0);
        response.setData(data);
        return response;
    }
}
