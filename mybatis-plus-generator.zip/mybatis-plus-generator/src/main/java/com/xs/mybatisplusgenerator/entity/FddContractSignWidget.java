package com.xs.mybatisplusgenerator.entity;

import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import java.io.Serializable;
import java.time.LocalDateTime;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Getter;
import lombok.Setter;

/**
 * <p>
 * 合同签署控件表，保存签署方需要填写的控件信息
 * </p>
 *
 * @author xs
 * @since 2023-03-16
 */
@Getter
@Setter
@TableName("t_fdd_contract_sign_widget")
@ApiModel(value = "FddContractSignWidget对象", description = "合同签署控件表，保存签署方需要填写的控件信息")
public class FddContractSignWidget implements Serializable {

    private static final long serialVersionUID = 1L;

    @ApiModelProperty("主键id")
    @TableId("id")
    private String id;

    @ApiModelProperty("t_fdd_contract_sign表主键")
    @TableField("contract_sign_id")
    private String contractSignId;

    @ApiModelProperty("控件信息")
    @TableField("widgets")
    private String widgets;

    @ApiModelProperty("表示这个控件内容是否已填写：0.未填写；1.已填写")
    @TableField("filled")
    private Integer filled;

    @ApiModelProperty("创建人")
    @TableField("created_by")
    private String createdBy;

    @ApiModelProperty("记录创建时间")
    @TableField("created_date")
    private LocalDateTime createdDate;

    @ApiModelProperty("最后操作人")
    @TableField("last_updated_by")
    private String lastUpdatedBy;

    @ApiModelProperty("最后更新时间")
    @TableField("last_updated_date")
    private LocalDateTime lastUpdatedDate;

    @ApiModelProperty("逻辑删除标记：1.删除；0.未删除")
    @TableField("remove_flag")
    private Integer removeFlag;

    @ApiModelProperty("逻辑删除时间戳")
    @TableField("remove_timestamp")
    private Long removeTimestamp;


}
