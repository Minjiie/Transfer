package com.xs.mybatisplusgenerator.mapper;

import com.xs.mybatisplusgenerator.entity.TmNeitPwoHistory;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;

/**
 * <p>
 *  Mapper 接口
 * </p>
 *
 * @author xs
 * @since 2023-03-27
 */
public interface TmNeitPwoHistoryMapper extends BaseMapper<TmNeitPwoHistory> {

}
