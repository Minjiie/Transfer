package com.xs.mybatisplusgenerator.service;

import com.xs.mybatisplusgenerator.entity.User;
import com.baomidou.mybatisplus.extension.service.IService;

/**
 * <p>
 * 用户表 服务类
 * </p>
 *
 * @author xs
 * @since 2023-03-16
 */
public interface UserService extends IService<User> {

}
