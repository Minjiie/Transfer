package com.xs.mybatisplusgenerator.service.impl;

import com.xs.mybatisplusgenerator.entity.TmNeitPwoHistory;
import com.xs.mybatisplusgenerator.mapper.TmNeitPwoHistoryMapper;
import com.xs.mybatisplusgenerator.service.TmNeitPwoHistoryService;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import org.springframework.stereotype.Service;

/**
 * <p>
 *  服务实现类
 * </p>
 *
 * @author xs
 * @since 2023-03-27
 */
@Service
public class TmNeitPwoHistoryServiceImp extends ServiceImpl<TmNeitPwoHistoryMapper, TmNeitPwoHistory> implements TmNeitPwoHistoryService {

}
